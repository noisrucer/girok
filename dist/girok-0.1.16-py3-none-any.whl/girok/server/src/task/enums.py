from enum import Enum

class TaskView(str, Enum):
    category = "category"
    list = "list"