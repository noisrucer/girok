DEFAULT_CATEGORY_COLOR = "yellow"
DEFAULT_TASK_COLOR = "blue"
CATEGORY_COLORS = ["yellow", "orange", "blue", "white", "brown", "green"]