APP_NAME=girok
BASE_URL=http://girok-server-balancer-1565927748.ap-northeast-1.elb.amazonaws.com
EMAIL_BASE_URL=https://girokemail.onrender.com
